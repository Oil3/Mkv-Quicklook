// FFmpegBridge.h
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
